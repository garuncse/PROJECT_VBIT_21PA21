from flask import Flask, request, render_template, redirect, url_for, flash
from flask_cors import CORS
from PIL import Image
import base64
import os
import json
import mysql.connector
import face_recognition
import numpy as np
import io

app = Flask(__name__)
app.secret_key = 'your_secret_key'
CORS(app)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/register', methods=['GET', 'POST'])
def registration():
    if request.method == 'POST':
        # Your existing registration logic
        data = request.form
        first_name = data['firstName']
        last_name = data['lastName']
        date_of_birth = data['dateOfBirth']
        gender = data['gender']
        mobile_number = data['mobileNumber']
        account_type = data['accountType']
        account_number = data['accountNumber']
        pin = data['pin']
        image_data = data['image_path']

        db_connection = mysql.connector.connect(
            host='localhost',
            user='root',
            password='',
            database='mydb'
        )
        cursor = db_connection.cursor()

        cursor.execute("SELECT COUNT(*) FROM users WHERE accountNumber = %s", (account_number,))
        count = cursor.fetchone()[0]

        if count > 0:
            cursor.close()
            db_connection.close()
            return 'User exists with this account!', 400

        if image_data.startswith('data:image/png;base64,'):
            image_data = image_data.replace('data:image/png;base64,', '')
            image_data = base64.b64decode(image_data)
            image_path = os.path.join('static/images', f"{account_number}.png")
            with open(image_path, 'wb') as f:
                f.write(image_data)

        cursor.execute("""INSERT INTO users (firstName, lastName, dateOfBirth, gender, mobileNumber, accountType, accountNumber, pin, images)
                          VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)""",
                       (first_name, last_name, date_of_birth, gender, mobile_number, account_type, account_number, pin, image_path.replace('\\', '/')))
        db_connection.commit()

        cursor.close()
        db_connection.close()

        return 'Registration successful', 200

    return render_template('registration.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        account_number = request.form['account_number']
        pin = request.form['pin']
        captured_images = request.form['captured_images']

        db_connection = mysql.connector.connect(
            host='localhost',
            user='root',
            password='',
            database='mydb'
        )
        cursor = db_connection.cursor()

        cursor.execute("SELECT pin FROM users WHERE accountNumber = %s", (account_number,))
        result = cursor.fetchone()

        if result:
            stored_pin = result[0]
            if stored_pin == pin:

                #extracting features of user image from which is stored in database.
                system_image_path = "./static/images/" + account_number + ".png"
                system_image = face_recognition.load_image_file(system_image_path)
                system_encoding = face_recognition.face_encodings(system_image)[0]
                # Save images
                matched_count=0
                image_data_list = json.loads(captured_images)
                threshold = 0.4  # Example threshold
                for index, image_data in enumerate(image_data_list):
                    if image_data.startswith('data:image/png;base64,'):
                        image_data = image_data.replace('data:image/png;base64,', '')
                        image_data = base64.b64decode(image_data)
                        image = Image.open(io.BytesIO(image_data)).convert('RGB')
                        image_array=np.array(image)
                        face_encodings = face_recognition.face_encodings(image_array)
                        if face_encodings:
                            face_encoding = face_encodings[0]
                            distance = face_recognition.face_distance([system_encoding], face_encoding)[0]
                            if distance < threshold:
                                matched_count += 1

                if matched_count > 6 :
                    return 'Login successful', 200
                else:
                    return 'Face does not match', 401

            else:
                return 'Incorrect PIN', 401

        else:
            return 'Incorrect account number', 401

    return render_template('login.html')

@app.route('/test')
def test():
    return render_template('test.html')

if __name__ == '__main__':
    app.run(debug=True)
